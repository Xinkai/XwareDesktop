# -*- coding: utf-8 -*-

from .adapter import XwareAdapter
